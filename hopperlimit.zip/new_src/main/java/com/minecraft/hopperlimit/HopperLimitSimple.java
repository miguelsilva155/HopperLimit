package com.minecraft.hopperlimit;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Versão simplificada do plugin HopperLimit para compilação
 * (Sem depender do PlotSquared)
 */
public class HopperLimitSimple extends JavaPlugin implements Listener, CommandExecutor {

    private static HopperLimitSimple instance;
    private final Pattern hopperPermPattern = Pattern.compile("hopperlimit\\.limit\\.(\\d+)");
    private final Pattern hopperSinglePermPattern = Pattern.compile("hopper\\.(\\d+)");
    private final Map<String, Integer> hopperLimitCache = new HashMap<>();
    private int defaultHopperLimit = 5;

    @Override
    public void onEnable() {
        instance = this;
        
        // Salvar configuração padrão
        saveDefaultConfig();
        
        // Carregar configuração
        defaultHopperLimit = getConfig().getInt("default-hopper-limit", 5);
        
        // Registrar eventos
        getServer().getPluginManager().registerEvents(this, this);
        
        // Registrar comando
        getCommand("hopperlimit").setExecutor(this);
        
        getLogger().info("HopperLimit ativado com sucesso!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HopperLimit desativado!");
    }
    
    /**
     * Manipula o evento de colocação de blocos para verificar se é um funil
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        // Verifica se o bloco sendo colocado é um funil
        if (event.getBlock().getType() != Material.HOPPER) {
            return;
        }

        Player player = event.getPlayer();
        
        // Verificar se o jogador tem bypass
        if (player.hasPermission("hopperlimit.bypass")) {
            return;
        }
        
        // Em uma versão real, aqui você verificaria se o bloco está dentro de um plot
        // Nesta versão simplificada, vamos apenas mostrar uma mensagem informativa
        
        // Verifica o limite de funis do jogador
        int hopperLimit = getPlayerHopperLimit(player);
        
        // Conta os funis atuais (simulação)
        int currentHoppers = 1; // Simulação - em um plugin real, isto contaria os hoppers no plot
        
        // Mensagem informativa
        String countMessage = "&aLimite de funis: %current%/%max% (Versão simplificada - não está contando realmente)";
        countMessage = countMessage.replace("%current%", String.valueOf(currentHoppers))
                                 .replace("%max%", String.valueOf(hopperLimit));
        
        player.sendMessage(formatMessage(countMessage));
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                if (!sender.hasPermission("hopperlimit.admin")) {
                    sender.sendMessage(formatMessage("&cVocê não tem permissão para usar este comando."));
                    return true;
                }
                // Salva config padrão se não existir
                saveDefaultConfig();
                // Recarrega do disco
                reloadConfig();
                // Atualiza o limite default
                defaultHopperLimit = getConfig().getInt("default-hopper-limit", 5);
                // Limpa o cache de limites
                hopperLimitCache.clear();
                sender.sendMessage(formatMessage("&aConfiguração recarregada com sucesso! Novo limite padrão: " + defaultHopperLimit));
                return true;

            case "count":
                if (!(sender instanceof Player)) {
                    sender.sendMessage(formatMessage("&cEste comando só pode ser executado por jogadores."));
                    return true;
                }
                
                Player player = (Player) sender;
                
                // Verifica o limite de funis do jogador
                int hopperLimit = getPlayerHopperLimit(player);
                
                // Mensagem informativa (versão simplificada)
                String countMessage = "&aSeu limite de funis: %max% (Versão simplificada)";
                countMessage = countMessage.replace("%max%", String.valueOf(hopperLimit));
                
                sender.sendMessage(formatMessage(countMessage));
                return true;

            default:
                sendHelpMessage(sender);
                return true;
        }
    }
    
    /**
     * Envia a mensagem de ajuda para o jogador
     */
    private void sendHelpMessage(CommandSender sender) {
        sender.sendMessage(formatMessage("&6==== HopperLimit - Comandos ===="));
        sender.sendMessage(formatMessage("&e/hopperlimit count &7- Verifica seu limite de funis"));
        
        if (sender.hasPermission("hopperlimit.admin")) {
            sender.sendMessage(formatMessage("&e/hopperlimit reload &7- Recarrega a configuração do plugin"));
        }
    }

    /**
     * Obtém o limite de funis de um jogador com base em suas permissões
     */
    public int getPlayerHopperLimit(Player player) {
        // Verifica o cache primeiro
        String playerName = player.getName();
        if (hopperLimitCache.containsKey(playerName)) {
            return hopperLimitCache.get(playerName);
        }
        
        // Por padrão, usa o limite definido na configuração
        int limit = defaultHopperLimit;
        
        // Verifica permissões tradicionais (hoppers.X)
        for (PermissionAttachmentInfo perm : player.getEffectivePermissions()) {
            String permission = perm.getPermission();
            
            if (permission.startsWith("hoppers.") && perm.getValue()) {
                try {
                    int permLimit = Integer.parseInt(permission.substring(8));
                    if (permLimit > limit) {
                        limit = permLimit;
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        
        // Verifica permissões no formato hopperlimit.limit.X
        for (PermissionAttachmentInfo perm : player.getEffectivePermissions()) {
            String permission = perm.getPermission();
            
            if (perm.getValue()) {
                Matcher matcher = hopperPermPattern.matcher(permission);
                if (matcher.matches()) {
                    try {
                        int permLimit = Integer.parseInt(matcher.group(1));
                        if (permLimit > limit) {
                            limit = permLimit;
                        }
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        
        // Verifica permissões no formato hopper.X
        for (PermissionAttachmentInfo perm : player.getEffectivePermissions()) {
            String permission = perm.getPermission();
            
            if (perm.getValue()) {
                Matcher matcher = hopperSinglePermPattern.matcher(permission);
                if (matcher.matches()) {
                    try {
                        int permLimit = Integer.parseInt(matcher.group(1));
                        if (permLimit > limit) {
                            limit = permLimit;
                        }
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        
        // Armazena no cache para consultas futuras
        hopperLimitCache.put(playerName, limit);
        
        return limit;
    }

    /**
     * Formata uma mensagem com cores
     */
    public String formatMessage(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    /**
     * Obtém a instância do plugin
     */
    public static HopperLimitSimple getInstance() {
        return instance;
    }
}