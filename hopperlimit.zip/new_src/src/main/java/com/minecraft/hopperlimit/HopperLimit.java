package com.minecraft.hopperlimit;

import com.minecraft.hopperlimit.commands.HopperCommands;
import com.minecraft.hopperlimit.listeners.HopperPlaceListener;
import com.minecraft.hopperlimit.utils.ConfigManager;
import com.minecraft.hopperlimit.utils.PlotUtils;

import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Plugin que limita o número de funis por plot baseado em permissões de jogadores
 */
public class HopperLimit extends JavaPlugin {

    private static HopperLimit instance;
    private ConfigManager configManager;
    private PlotUtils plotUtils;

    @Override
    public void onEnable() {
        instance = this;
        
        // Inicializa a configuração
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        
        // Verifica se o PlotSquared está presente
        PluginManager pm = getServer().getPluginManager();
        Plugin plotSquared = pm.getPlugin("PlotSquared");
        
        if (plotSquared == null || !plotSquared.isEnabled()) {
            getLogger().severe("PlotSquared não foi encontrado ou não está ativado!");
            getLogger().severe("O HopperLimit requer o PlotSquared para funcionar corretamente!");
            getLogger().severe("Desativando o plugin...");
            pm.disablePlugin(this);
            return;
        }
        
        getLogger().info("PlotSquared detectado: v" + plotSquared.getDescription().getVersion());
        
        // Inicializa a utilidade de plots
        plotUtils = new PlotUtils(this);
        
        // Registra o comando
        registerCommands();
        
        // Registra os listeners
        registerListeners();
        
        getLogger().info("HopperLimit ativado com sucesso!");
        getLogger().info("Desenvolvido por: Miguel");
    }

    @Override
    public void onDisable() {
        getLogger().info("HopperLimit desativado com sucesso!");
    }
    
    /**
     * Registra os comandos do plugin
     */
    private void registerCommands() {
        PluginCommand mainCommand = getCommand("hopperlimit");
        if (mainCommand != null) {
            HopperCommands commandExecutor = new HopperCommands(this);
            mainCommand.setExecutor(commandExecutor);
            mainCommand.setTabCompleter(commandExecutor);
        }
    }
    
    /**
     * Registra os listeners do plugin
     */
    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new HopperPlaceListener(this), this);
    }
    
    /**
     * Recarrega a configuração do plugin
     */
    public void reloadPlugin() {
        reloadConfig();
        configManager = new ConfigManager(this);
    }
    
    /**
     * Retorna a instância do plugin
     * @return Instância do HopperLimit
     */
    public static HopperLimit getInstance() {
        return instance;
    }
    
    /**
     * Retorna a utilidade de plots
     * @return Utilidade de plots
     */
    public PlotUtils getPlotUtils() {
        return plotUtils;
    }
    
    /**
     * Traduz códigos de cores
     * @param message Mensagem para traduzir
     * @return Mensagem com cores traduzidas
     */
    public String colorize(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    /**
     * Retorna o gerenciador de configuração
     * @return Gerenciador de configuração
     */
    public ConfigManager getConfigManager() {
        return configManager;
    }
}