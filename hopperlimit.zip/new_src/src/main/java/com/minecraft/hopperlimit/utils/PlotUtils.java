package com.minecraft.hopperlimit.utils;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import com.minecraft.hopperlimit.HopperLimit;

/**
 * Utilidades para interagir com plots do PlotSquared
 * Esta classe usa reflexão para interagir com o PlotSquared sem depender diretamente da sua API
 */
public class PlotUtils {

    private final HopperLimit plugin;
    private final Plugin plotSquared;
    
    public PlotUtils(HopperLimit plugin) {
        this.plugin = plugin;
        this.plotSquared = plugin.getServer().getPluginManager().getPlugin("PlotSquared");
    }
    
    /**
     * Verifica se um jogador está em um plot
     * @param player Jogador para verificar
     * @return true se o jogador está em um plot, false caso contrário
     */
    public boolean isPlayerInPlot(Player player) {
        try {
            String version = plotSquared.getDescription().getVersion();
            plugin.getLogger().info("Detectada versão do PlotSquared: " + version);
            
            Object plotLocation = null;
            Class<?> locationClass = null;
            
            // Tentar diferentes pacotes para diferentes versões do PlotSquared
            try {
                // PlotSquared 6+
                locationClass = Class.forName("com.plotsquared.core.location.Location");
                plotLocation = locationClass.getMethod("at", String.class, int.class, int.class, int.class)
                        .invoke(null, player.getWorld().getName(), player.getLocation().getBlockX(), 
                                player.getLocation().getBlockY(), player.getLocation().getBlockZ());
            } catch (ClassNotFoundException e) {
                try {
                    // PlotSquared 5
                    locationClass = Class.forName("com.github.intellectualsites.plotsquared.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(player.getWorld().getName(), player.getLocation().getBlockX(), 
                                    player.getLocation().getBlockY(), player.getLocation().getBlockZ());
                } catch (ClassNotFoundException e2) {
                    // PlotSquared 4 ou anterior
                    locationClass = Class.forName("com.intellectualcrafters.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(player.getWorld().getName(), player.getLocation().getBlockX(), 
                                    player.getLocation().getBlockY(), player.getLocation().getBlockZ());
                }
            }
            
            if (locationClass == null || plotLocation == null) {
                return false;
            }
            
            // Obtém a área do plot
            Object plotArea = null;
            try {
                plotArea = locationClass.getMethod("getPlotArea").invoke(plotLocation);
            } catch (NoSuchMethodException e) {
                // Método alternativo para versões mais antigas
                Class<?> psClass = Class.forName("com.intellectualcrafters.plot.PS");
                Object ps = psClass.getMethod("get").invoke(null);
                plotArea = psClass.getMethod("getPlotArea", String.class, String.class)
                        .invoke(ps, player.getWorld().getName(), null);
            }
            
            if (plotArea == null) {
                return false;
            }
            
            // Tentar obter o plot
            Object plot = null;
            try {
                // PlotSquared 6+ / 5
                Class<?> plotAreaClass = plotArea.getClass();
                plot = plotAreaClass.getMethod("getPlot", locationClass).invoke(plotArea, plotLocation);
            } catch (NoSuchMethodException e) {
                // PlotSquared 4 ou anterior
                Class<?> plotManagerClass = Class.forName("com.intellectualcrafters.plot.object.PlotManager");
                Object manager = plotArea.getClass().getMethod("getPlotManager").invoke(plotArea);
                plot = plotManagerClass.getMethod("getPlot", locationClass).invoke(manager, plotLocation);
            }
            
            return plot != null;
        } catch (Exception e) {
            plugin.getLogger().warning("Erro ao verificar se jogador está em um plot: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Obtém o plot em que um jogador está
     * @param player Jogador para verificar
     * @return Plot em que o jogador está, ou null se não estiver em um plot
     */
    public Object getPlayerPlot(Player player) {
        try {
            Object plotLocation = null;
            Class<?> locationClass = null;
            
            // Tentar diferentes pacotes para diferentes versões do PlotSquared
            try {
                // PlotSquared 6+
                locationClass = Class.forName("com.plotsquared.core.location.Location");
                plotLocation = locationClass.getMethod("at", String.class, int.class, int.class, int.class)
                        .invoke(null, player.getWorld().getName(), player.getLocation().getBlockX(), 
                                player.getLocation().getBlockY(), player.getLocation().getBlockZ());
            } catch (ClassNotFoundException e) {
                try {
                    // PlotSquared 5
                    locationClass = Class.forName("com.github.intellectualsites.plotsquared.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(player.getWorld().getName(), player.getLocation().getBlockX(), 
                                    player.getLocation().getBlockY(), player.getLocation().getBlockZ());
                } catch (ClassNotFoundException e2) {
                    // PlotSquared 4 ou anterior
                    locationClass = Class.forName("com.intellectualcrafters.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(player.getWorld().getName(), player.getLocation().getBlockX(), 
                                    player.getLocation().getBlockY(), player.getLocation().getBlockZ());
                }
            }
            
            if (locationClass == null || plotLocation == null) {
                return null;
            }
            
            // Obtém a área do plot
            Object plotArea = null;
            try {
                plotArea = locationClass.getMethod("getPlotArea").invoke(plotLocation);
            } catch (NoSuchMethodException e) {
                // Método alternativo para versões mais antigas
                Class<?> psClass = Class.forName("com.intellectualcrafters.plot.PS");
                Object ps = psClass.getMethod("get").invoke(null);
                plotArea = psClass.getMethod("getPlotArea", String.class, String.class)
                        .invoke(ps, player.getWorld().getName(), null);
            }
            
            if (plotArea == null) {
                return null;
            }
            
            // Tentar obter o plot
            Object plot = null;
            try {
                // PlotSquared 6+ / 5
                Class<?> plotAreaClass = plotArea.getClass();
                plot = plotAreaClass.getMethod("getPlot", locationClass).invoke(plotArea, plotLocation);
            } catch (NoSuchMethodException e) {
                // PlotSquared 4 ou anterior
                Class<?> plotManagerClass = Class.forName("com.intellectualcrafters.plot.object.PlotManager");
                Object manager = plotArea.getClass().getMethod("getPlotManager").invoke(plotArea);
                plot = plotManagerClass.getMethod("getPlot", locationClass).invoke(manager, plotLocation);
            }
            
            return plot;
        } catch (Exception e) {
            plugin.getLogger().warning("Erro ao obter plot do jogador: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Verifica se um bloco está em um plot específico
     * @param block Bloco para verificar
     * @param plot Plot para verificar
     * @return true se o bloco está no plot, false caso contrário
     */
    public boolean isBlockInPlot(Block block, Object plot) {
        if (plot == null) {
            return false;
        }
        
        try {
            // Compara com base na própria localização do bloco
            Player tempPlayer = plugin.getServer().getOnlinePlayers().iterator().next();
            if (tempPlayer == null) {
                return false;
            }
            
            // Temporariamente "teleporta" o jogador para o bloco (sem realmente teleportar)
            org.bukkit.Location originalLocation = tempPlayer.getLocation();
            org.bukkit.Location blockLocation = block.getLocation();
            
            Object playerPlot = getSpecificPlot(blockLocation.getWorld().getName(), 
                                               blockLocation.getBlockX(), 
                                               blockLocation.getBlockY(), 
                                               blockLocation.getBlockZ());
            
            if (playerPlot == null) {
                return false;
            }
            
            // Compara os plots através de IDs ou hashCode
            Class<?> plotClass = plot.getClass();
            Object plotId1 = null;
            Object plotId2 = null;
            
            try {
                // Primeiro tenta obter o ID
                plotId1 = plotClass.getMethod("getId").invoke(plot);
                plotId2 = plotClass.getMethod("getId").invoke(playerPlot);
            } catch (NoSuchMethodException e) {
                // Se não tiver método getId, usa toString() ou hashCode()
                return plot.toString().equals(playerPlot.toString()) || 
                       plot.hashCode() == playerPlot.hashCode();
            }
            
            return plotId1 != null && plotId1.equals(plotId2);
        } catch (Exception e) {
            plugin.getLogger().warning("Erro ao verificar se bloco está em um plot: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private Object getSpecificPlot(String world, int x, int y, int z) {
        try {
            Object plotLocation = null;
            Class<?> locationClass = null;
            
            // Tentar diferentes pacotes para diferentes versões do PlotSquared
            try {
                // PlotSquared 6+
                locationClass = Class.forName("com.plotsquared.core.location.Location");
                plotLocation = locationClass.getMethod("at", String.class, int.class, int.class, int.class)
                        .invoke(null, world, x, y, z);
            } catch (ClassNotFoundException e) {
                try {
                    // PlotSquared 5
                    locationClass = Class.forName("com.github.intellectualsites.plotsquared.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(world, x, y, z);
                } catch (ClassNotFoundException e2) {
                    // PlotSquared 4 ou anterior
                    locationClass = Class.forName("com.intellectualcrafters.plot.object.Location");
                    plotLocation = locationClass.getConstructor(String.class, int.class, int.class, int.class)
                            .newInstance(world, x, y, z);
                }
            }
            
            if (locationClass == null || plotLocation == null) {
                return null;
            }
            
            // Obtém a área do plot
            Object plotArea = null;
            try {
                plotArea = locationClass.getMethod("getPlotArea").invoke(plotLocation);
            } catch (NoSuchMethodException e) {
                // Método alternativo para versões mais antigas
                Class<?> psClass = Class.forName("com.intellectualcrafters.plot.PS");
                Object ps = psClass.getMethod("get").invoke(null);
                plotArea = psClass.getMethod("getPlotArea", String.class, String.class)
                        .invoke(ps, world, null);
            }
            
            if (plotArea == null) {
                return null;
            }
            
            // Tentar obter o plot
            try {
                // PlotSquared 6+ / 5
                Class<?> plotAreaClass = plotArea.getClass();
                return plotAreaClass.getMethod("getPlot", locationClass).invoke(plotArea, plotLocation);
            } catch (NoSuchMethodException e) {
                // PlotSquared 4 ou anterior
                Class<?> plotManagerClass = Class.forName("com.intellectualcrafters.plot.object.PlotManager");
                Object manager = plotArea.getClass().getMethod("getPlotManager").invoke(plotArea);
                return plotManagerClass.getMethod("getPlot", locationClass).invoke(manager, plotLocation);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Erro ao obter plot específico: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Conta o número de funis em um plot
     * @param plot Plot para contar
     * @return Número de funis no plot
     */
    public int countHoppersInPlot(Object plot) {
        if (plot == null) {
            plugin.getLogger().warning("Plot nulo, não é possível contar funis");
            return 0;
        }
        
        int count = 0;
        
        // Registra informações de debug (versão 1.0.2)
        plugin.getLogger().info("Iniciando contagem de funis em plot (v1.0.2)");
        plugin.getLogger().info("Classe do plot: " + plot.getClass().getName());
        
        try {
            // Definição de variáveis que serão usadas para contagem
            int minX = 0, minZ = 0, maxX = 0, maxZ = 0;
            String worldName = null;
            
            // Extra debug information
            try {
                java.lang.reflect.Method[] methods = plot.getClass().getMethods();
                for (java.lang.reflect.Method method : methods) {
                    if (method.getName().contains("get") && 
                        method.getParameterCount() == 0 && 
                        (method.getName().contains("Bottom") || method.getName().contains("Top") ||
                         method.getName().contains("World") || method.getName().contains("world"))) {
                        plugin.getLogger().info("Método disponível: " + method.getName() + " -> " + method.getReturnType().getName());
                    }
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("Erro ao listar métodos do plot: " + ex.getMessage());
            }
            
            try {
                // Primeiro tenta obter usando a API moderna PlotSquared 6+
                plugin.getLogger().info("Tentando obter coordenadas com API moderna (PlotSquared 6+)");
                Object bottomAbs = plot.getClass().getMethod("getBottomAbs").invoke(plot);
                Object topAbs = plot.getClass().getMethod("getTopAbs").invoke(plot);
                
                Class<?> blockLocClass = Class.forName("com.plotsquared.core.location.BlockLoc");
                minX = (int) blockLocClass.getMethod("getX").invoke(bottomAbs);
                minZ = (int) blockLocClass.getMethod("getZ").invoke(bottomAbs);
                maxX = (int) blockLocClass.getMethod("getX").invoke(topAbs);
                maxZ = (int) blockLocClass.getMethod("getZ").invoke(topAbs);
                
                worldName = (String) plot.getClass().getMethod("getWorldName").invoke(plot);
                plugin.getLogger().info("Coordenadas obtidas com sucesso (API moderna): " + minX + "," + minZ + " até " + maxX + "," + maxZ);
            } catch (Exception e) {
                // Se falhar, tenta usar a API mais antiga
                try {
                    Object bottom = plot.getClass().getMethod("getBottom").invoke(plot);
                    Object top = plot.getClass().getMethod("getTop").invoke(plot);
                    
                    Class<?> locationClass = bottom.getClass();
                    minX = (int) locationClass.getMethod("getX").invoke(bottom);
                    minZ = (int) locationClass.getMethod("getZ").invoke(bottom);
                    maxX = (int) locationClass.getMethod("getX").invoke(top);
                    maxZ = (int) locationClass.getMethod("getZ").invoke(top);
                    
                    // Detecta o método certo para obter o nome do mundo
                    try {
                        // Tenta getWorldName (versão 6+)
                        worldName = (String) plot.getClass().getMethod("getWorldName").invoke(plot);
                    } catch (NoSuchMethodException worldMethodEx) {
                        try {
                            // Tenta getWorld (versão antiga)
                            worldName = (String) plot.getClass().getMethod("getWorld").invoke(plot);
                        } catch (NoSuchMethodException oldWorldMethodEx) {
                            try {
                                // Tenta getArea().getWorldName()
                                Object area = plot.getClass().getMethod("getArea").invoke(plot);
                                worldName = (String) area.getClass().getMethod("getWorldName").invoke(area);
                            } catch (NoSuchMethodException veryOldMethodEx) {
                                // Última tentativa: procura algum método que retorne String
                                for (java.lang.reflect.Method method : plot.getClass().getMethods()) {
                                    if (method.getReturnType() == String.class && 
                                        method.getParameterCount() == 0 && 
                                        (method.getName().contains("world") || method.getName().contains("World"))) {
                                        worldName = (String) method.invoke(plot);
                                        break;
                                    }
                                }
                                
                                // Se ainda for nulo, usa o mundo do jogador (v1.0.2)
                                if (worldName == null) {
                                    try {
                                        // Vamos tentar extrair o ID do plot e procurar por mais informações
                                        plugin.getLogger().info("Tentando extrair ID do plot para obter o mundo");
                                        Object plotId = null;
                                        try {
                                            plotId = plot.getClass().getMethod("getId").invoke(plot);
                                            plugin.getLogger().info("ID do plot obtido: " + plotId);
                                            // Tenta extrair o mundo a partir do ID, que pode conter o nome do mundo
                                            if (plotId != null) {
                                                String idStr = plotId.toString();
                                                if (idStr.contains("-") || idStr.contains(";")) {
                                                    String[] parts = idStr.split("[;-]");
                                                    if (parts.length > 0 && parts[0] != null && !parts[0].trim().isEmpty()) {
                                                        worldName = parts[0];
                                                        plugin.getLogger().info("Mundo obtido do ID do plot: " + worldName);
                                                    }
                                                }
                                            }
                                        } catch (Exception idEx) {
                                            plugin.getLogger().warning("Erro ao tentar extrair ID do plot: " + idEx.getMessage());
                                        }
                                        
                                        // Se ainda for nulo, tenta usar jogadores online ou mundos
                                        if (worldName == null) {
                                            if (!plugin.getServer().getOnlinePlayers().isEmpty()) {
                                                worldName = plugin.getServer().getOnlinePlayers().iterator().next().getWorld().getName();
                                                plugin.getLogger().info("Usando mundo do primeiro jogador online: " + worldName);
                                            } else {
                                                worldName = plugin.getServer().getWorlds().get(0).getName();
                                                plugin.getLogger().info("Usando primeiro mundo disponível: " + worldName);
                                            }
                                            plugin.getLogger().warning("Não foi possível determinar o mundo do plot, usando o mundo padrão: " + worldName);
                                        }
                                    } catch (Exception extraEx) {
                                        plugin.getLogger().severe("Erro ao tentar determinar o mundo do plot: " + extraEx.getMessage());
                                        worldName = plugin.getServer().getWorlds().get(0).getName();
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e2) {
                    plugin.getLogger().warning("Não foi possível determinar as coordenadas do plot!");
                    e2.printStackTrace();
                    return count;
                }
            }
            
            if (worldName == null) {
                plugin.getLogger().warning("Nome do mundo do plot é nulo!");
                return count;
            }
            
            // Obtém o mundo do Bukkit
            org.bukkit.World world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("Mundo " + worldName + " não encontrado!");
                return count;
            }
            
            plugin.getLogger().info("Contando funis no plot de " + minX + "," + minZ + " até " + maxX + "," + maxZ + " no mundo " + worldName);
            
            // Percorre todos os blocos dentro do plot
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int y = 0; y <= 255; y++) {
                        Block block = world.getBlockAt(x, y, z);
                        if (block.getType() == Material.HOPPER) {
                            count++;
                        }
                    }
                }
            }
            
            plugin.getLogger().info("Total de funis encontrados: " + count);
        } catch (Exception e) {
            plugin.getLogger().warning("Erro ao contar funis em um plot: " + e.getMessage());
            e.printStackTrace();
        }
        
        return count;
    }
}