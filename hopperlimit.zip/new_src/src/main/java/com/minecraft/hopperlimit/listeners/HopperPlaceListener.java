package com.minecraft.hopperlimit.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;

import com.minecraft.hopperlimit.HopperLimit;
import com.minecraft.hopperlimit.utils.ConfigManager;
import com.minecraft.hopperlimit.utils.PlotUtils;

/**
 * Listener para controlar colocação de funis
 */
public class HopperPlaceListener implements Listener {

    private final HopperLimit plugin;
    private final ConfigManager configManager;
    private final PlotUtils plotUtils;
    
    public HopperPlaceListener(HopperLimit plugin) {
        this.plugin = plugin;
        this.configManager = plugin.getConfigManager();
        this.plotUtils = plugin.getPlotUtils();
    }
    
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        // Verifica se o bloco é um funil
        if (event.getBlockPlaced().getType() != Material.HOPPER) {
            return;
        }
        
        Player player = event.getPlayer();
        
        // Verifica se o jogador tem bypass
        if (player.hasPermission("hopperlimit.bypass")) {
            plugin.getLogger().info("Jogador " + player.getName() + " tem bypass para limite de funis");
            return;
        }
        
        // Verifica se o bloco está em um plot
        if (!plotUtils.isPlayerInPlot(player)) {
            plugin.getLogger().info("Bloco colocado fora de um plot");
            return; // Não limitar fora de plots
        }
        
        Object plot = plotUtils.getPlayerPlot(player);
        if (plot == null) {
            plugin.getLogger().info("Não foi possível obter o plot do jogador");
            return;
        }
        
        // Obtém o limite do jogador
        int hopperLimit = configManager.getPlayerHopperLimit(player);
        plugin.getLogger().info("Limite de funis do jogador " + player.getName() + ": " + hopperLimit);
        
        // Conta os funis no plot
        int currentHoppers = plotUtils.countHoppersInPlot(plot);
        plugin.getLogger().info("Quantidade atual de funis no plot: " + currentHoppers);
        
        // Pequena correção para evitar problemas (v1.0.2)
        if (currentHoppers <= 0) {
            // Se houve algum erro na contagem, permite a colocação desta vez
            plugin.getLogger().warning("Erro na contagem de funis, permitindo colocação");
            // Debug: Tentativa de identificar o tipo de plot
            try {
                plugin.getLogger().info("Classe do plot: " + plot.getClass().getName());
                java.lang.reflect.Method[] methods = plot.getClass().getMethods();
                plugin.getLogger().info("Métodos disponíveis:");
                for (java.lang.reflect.Method method : methods) {
                    if (method.getName().contains("get") && method.getParameterCount() == 0) {
                        plugin.getLogger().info("  " + method.getName() + " -> " + method.getReturnType().getName());
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Erro ao analisar classe do plot: " + e.getMessage());
            }
            return;
        }
        
        // Verifica se atingiu o limite
        if (currentHoppers >= hopperLimit) {
            event.setCancelled(true);
            
            String message = configManager.getMessage("limit-reached", "§cVocê atingiu o limite de §6{limit} §cfunis neste plot!")
                    .replace("{limit}", String.valueOf(hopperLimit));
            
            player.sendMessage(configManager.getPrefix() + message);
            plugin.getLogger().info("Bloqueada colocação de funil para " + player.getName() + " (limite atingido)");
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        // Verifica se o inventário é um dispensador/dropper e se o jogador está tentando colocar um funil nele
        if (event.getInventory().getType() != InventoryType.DISPENSER && 
            event.getInventory().getType() != InventoryType.DROPPER) {
            return;
        }
        
        if (event.getCursor() == null || event.getCursor().getType() != Material.HOPPER) {
            return;
        }
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        
        // Verifica se o jogador tem bypass
        if (player.hasPermission("hopperlimit.bypass")) {
            return;
        }
        
        // Verifica se está em um plot
        if (!plotUtils.isPlayerInPlot(player)) {
            return;
        }
        
        Object plot = plotUtils.getPlayerPlot(player);
        if (plot == null) {
            return;
        }
        
        // Obtém o limite do jogador
        int hopperLimit = configManager.getPlayerHopperLimit(player);
        
        // Conta os funis no plot
        int currentHoppers = plotUtils.countHoppersInPlot(plot);
        
        // Verifica se atingiu o limite
        if (currentHoppers >= hopperLimit) {
            event.setCancelled(true);
            
            String message = configManager.getMessage("limit-reached", "§cVocê atingiu o limite de §6{limit} §cfunis neste plot!")
                    .replace("{limit}", String.valueOf(hopperLimit));
            
            player.sendMessage(configManager.getPrefix() + message);
        }
    }
}