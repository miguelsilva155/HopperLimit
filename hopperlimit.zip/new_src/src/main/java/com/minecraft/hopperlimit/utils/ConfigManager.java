package com.minecraft.hopperlimit.utils;

import com.minecraft.hopperlimit.HopperLimit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

/**
 * Gerencia a configuração do plugin
 */
public class ConfigManager {

    private final HopperLimit plugin;
    private final FileConfiguration config;
    
    public ConfigManager(HopperLimit plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
    }
    
    /**
     * Obtém o limite de funis de um jogador com base em suas permissões
     * @param player Jogador para verificar
     * @return Limite de funis do jogador
     */
    public int getPlayerHopperLimit(Player player) {
        // Se tiver bypass, retorna Integer.MAX_VALUE
        if (player.hasPermission("hopperlimit.bypass")) {
            return Integer.MAX_VALUE;
        }
        
        int limit = config.getInt("default-hopper-limit", 5);
        
        // Formato 1: hopperlimit.limit.X
        for (int i = 1000; i >= 1; i--) {
            if (player.hasPermission("hopperlimit.limit." + i)) {
                limit = Math.max(limit, i);
                break;
            }
        }
        
        // Formato 2: hoppers.X
        for (int i = 1000; i >= 1; i--) {
            if (player.hasPermission("hoppers." + i)) {
                limit = Math.max(limit, i);
                break;
            }
        }
        
        // Formato 3: hopper.X (flexível, para qualquer número)
        for (int i = 1000; i >= 1; i--) {
            if (player.hasPermission("hopper." + i)) {
                limit = Math.max(limit, i);
            }
        }
        
        return limit;
    }
    
    /**
     * Obtém uma mensagem da configuração
     * @param path Caminho da mensagem
     * @param defaultValue Valor padrão
     * @return Mensagem colorizada
     */
    public String getMessage(String path, String defaultValue) {
        String message = config.getString("messages." + path, defaultValue);
        return plugin.colorize(message);
    }
    
    /**
     * Obtém o prefixo das mensagens
     * @return Prefixo colorizado
     */
    public String getPrefix() {
        return getMessage("prefix", "&7[&6HopperLimit&7] ");
    }
}