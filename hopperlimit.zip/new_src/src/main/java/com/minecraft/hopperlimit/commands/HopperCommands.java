package com.minecraft.hopperlimit.commands;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import com.minecraft.hopperlimit.HopperLimit;
import com.minecraft.hopperlimit.utils.ConfigManager;
import com.minecraft.hopperlimit.utils.PlotUtils;

/**
 * Gerenciador de comandos do plugin
 */
public class HopperCommands implements CommandExecutor, TabCompleter {

    private final HopperLimit plugin;
    private final ConfigManager configManager;
    private final PlotUtils plotUtils;
    
    public HopperCommands(HopperLimit plugin) {
        this.plugin = plugin;
        this.configManager = plugin.getConfigManager();
        this.plotUtils = plugin.getPlotUtils();
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cEste comando só pode ser executado por jogadores.");
            return true;
        }
        
        Player player = (Player) sender;
        String prefix = configManager.getPrefix();
        
        if (args.length == 0) {
            // Exibe ajuda
            player.sendMessage(prefix + "§aComandos disponíveis:");
            player.sendMessage("§a/hopperlimit count §7- §eVerifica quantos funis existem no plot");
            
            if (player.hasPermission("hopperlimit.admin")) {
                player.sendMessage("§a/hopperlimit reload §7- §eRecarrega a configuração do plugin");
            }
            
            return true;
        }
        
        if (args[0].equalsIgnoreCase("count")) {
            // Verifica se o jogador está em um plot
            if (!plotUtils.isPlayerInPlot(player)) {
                player.sendMessage(prefix + configManager.getMessage("not-in-plot", "§cVocê precisa estar em um plot para usar este comando."));
                return true;
            }
            
            Object plot = plotUtils.getPlayerPlot(player);
            int hopperCount = plotUtils.countHoppersInPlot(plot);
            int hopperLimit = configManager.getPlayerHopperLimit(player);
            
            String message = configManager.getMessage("hopper-count", "§aExistem §6{count}§a funis neste plot. Seu limite é de §6{limit}§a funis.")
                    .replace("{count}", String.valueOf(hopperCount))
                    .replace("{limit}", hopperLimit == Integer.MAX_VALUE ? "∞" : String.valueOf(hopperLimit));
            
            player.sendMessage(prefix + message);
            return true;
        }
        
        if (args[0].equalsIgnoreCase("reload")) {
            // Verifica permissão
            if (!player.hasPermission("hopperlimit.admin")) {
                player.sendMessage(prefix + configManager.getMessage("no-permission", "§cVocê não tem permissão para fazer isso."));
                return true;
            }
            
            // Recarrega o plugin
            plugin.reloadPlugin();
            
            player.sendMessage(prefix + configManager.getMessage("reload-success", "§aConfigurações recarregadas com sucesso!"));
            return true;
        }
        
        // Comando desconhecido
        player.sendMessage(prefix + "§cComando desconhecido. Use §6/hopperlimit§c para ver a lista de comandos.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.add("count");
            
            if (sender.hasPermission("hopperlimit.admin")) {
                completions.add("reload");
            }
        }
        
        return completions;
    }
}